# Coding Bat

1. Sign up for an account at https://codingbat.com/java
1. Click on the ```prefs``` link 
1. Put your instructor's email address in the **Teacher Share** text box.
    1. Your instructional staff will let you know which email you should enter.

1. Complete the first 15 exercises under **String-1** (first 5 rows helloName - middleTwo)
