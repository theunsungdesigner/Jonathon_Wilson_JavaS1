import java.util.Scanner;
public class if26 {


    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter your current weight");
        int currentWeight = scan.nextInt();



        System.out.println("Noted, " + currentWeight + "lbs" + " is current weight,  I also have calculations on these current planets");
        String[] Planets = {"1.Venus", "2.Mars", "3.Jupiter", "4.Saturn", "5.Uranus", "6.Neptune"};

        for (int i = 0; i < Planets.length; i++) {
            System.out.println(Planets[i]);
        }
        Scanner scan2 = new Scanner(System.in);
        String userPlanet = scan2.nextLine((Planets.)


        System.out.println("which planet would you like to visit?");

        System.out.println(userPlanet);








    }
}
