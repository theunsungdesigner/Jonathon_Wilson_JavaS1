# Katas

## UML Diagram

Using [draw.io](http://draw.io) or a similar tool, create UML Diagrams for each of the below objects. Be sure to put some thought into what properties and methods you may want these objects to have. Remember Grady Booch's definition of an object - "An object has state, behavior, and identity."

Objects:

- Radio
- TV
- Car
- Computer Mouse
- Coffee Maker
- Microwave

---
© 2019 Trilogy Education Services
