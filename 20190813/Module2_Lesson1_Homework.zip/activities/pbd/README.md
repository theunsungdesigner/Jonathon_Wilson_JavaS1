# Programming By Doing
* Create a new IntelliJ project called ```<Firsname><Lastname>U1M2L1PBD``` where Firstname and Lastename are your first name and last name respectively.
* Implement solutions for the following exercises found at https://programmingbydoing.com/
  * The solution for each problem should be in its own Java file

1. If Statements:
    1. 26
    1. 27
    1. 28
1. Random Numbers:
    1. 43
    1. 44
    1. 45
1. While Loops:
    1. 49
    1. 53
    1. 54
