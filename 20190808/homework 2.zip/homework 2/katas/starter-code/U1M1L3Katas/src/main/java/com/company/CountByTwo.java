package com.company;

public class CountByTwo {

    public static void main(String[] args) {

    }
}
