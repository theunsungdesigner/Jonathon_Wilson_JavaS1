package com.company;

public class RangeChecker {

    public static void main(String[] args) {

    }
}
