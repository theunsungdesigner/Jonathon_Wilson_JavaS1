package com.company;

public class UltimateQuestion {

    public static void main(String[] args) {

    }
}
