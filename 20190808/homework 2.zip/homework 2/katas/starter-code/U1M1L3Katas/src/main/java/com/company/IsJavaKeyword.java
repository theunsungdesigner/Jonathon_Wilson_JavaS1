package com.company;

public class IsJavaKeyword {

    public static void main(String[] args) {

    }
}
