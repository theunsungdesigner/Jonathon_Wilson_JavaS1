package com.company;

public class FavoriteProgrammingLanguage {

    public static void main(String[] args) {

    }
}
