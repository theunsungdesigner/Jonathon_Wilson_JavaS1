package com.company;

public class EvenOrOdd {

    public static void main(String[] args) {

    }
}
