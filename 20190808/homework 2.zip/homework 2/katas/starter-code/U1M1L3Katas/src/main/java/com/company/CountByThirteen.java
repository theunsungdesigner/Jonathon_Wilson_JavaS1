package com.company;

public class CountByThirteen {

    public static void main(String[] args) {

    }
}