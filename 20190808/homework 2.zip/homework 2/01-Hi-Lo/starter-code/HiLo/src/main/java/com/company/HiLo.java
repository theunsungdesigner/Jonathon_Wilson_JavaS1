package com.company;


        public class HiLo {

            public static void main(String[] args) {
                int x = 3;
                int y = 2;

                System.out.println(x);

            }
    }

