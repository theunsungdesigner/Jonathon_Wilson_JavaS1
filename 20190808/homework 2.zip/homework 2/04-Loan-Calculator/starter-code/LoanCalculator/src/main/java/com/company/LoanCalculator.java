import java.util.Scanner;
package com.company;
//        i = IRR
//        L = Loan amount
//        F = Points and all other lender fees
//        P = Monthly payment
//        n = Month when the balance is paid in full
//        Bn = Balance in month n

//P = L[c(1 + c)n]/[(1 + c)n - 1]
public class LoanCalculator {
    public static void main(String[] args) {

        System.out.println( "Whats your monthly payment?");
        int userPayment = Integer.parseInt(scan.nextLine());

        System.out.println(userPayment);
        System.out.println("Whats your Loan amount?");




    }
}
