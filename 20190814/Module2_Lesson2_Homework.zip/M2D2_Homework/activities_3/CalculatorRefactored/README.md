# Simple Calculator Refactored

## Specification

Refactor your simple calculator application to overload each method to handle each of the below input types:

- `int`
- `long`
- `float`
- `double`

Once you have the Calculator class refactored, test using `CalculatorTest`.
