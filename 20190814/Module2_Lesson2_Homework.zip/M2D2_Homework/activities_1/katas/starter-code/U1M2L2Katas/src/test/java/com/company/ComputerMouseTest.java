package com.company;

import org.junit.Test;

import static org.junit.Assert.*;

public class ComputerMouseTest {

    // @Test
    // public void testComputerMouse() {

    //     ComputerMouse computerMouse = new ComputerMouse("Razer", "Naga", 960, 540, new int[] {0, 0});

    //     String expect = "Expected to be able to instantiate a CoffeeMaker object";
    //     assertTrue(expect, computerMouse instanceof ComputerMouse);

    //     expect = "Values should be initialized by the constructor and accessible by getters";
    //     assertEquals(expect, "Razer", computerMouse.getManufacturer());
    //     assertEquals(expect, "Naga", computerMouse.getModel());
    //     assertEquals(expect, 960, computerMouse.getxPosition());
    //     assertEquals(expect, 540, computerMouse.getyPosition());
    //     assertArrayEquals(expect, new int[] {0,0}, computerMouse.getLastClickedLocation());
    // }
}
